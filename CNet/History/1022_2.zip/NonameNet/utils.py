import os
import random
import sys
from math import log
from os.path import isdir, isfile
import numpy as np
import torch
from scipy.spatial import kdtree
from tqdm import tqdm

import args


def sp_point_match(src_points, src_feature, tgt_feature):
    src_points = src_points.permute((0, 2, 1))
    src_sorted_points = []
    valid_list = [False for _ in range(args.top_k_num)]
    valid_list = [valid_list for _ in range(args.batch_size)]
    src_feature_cpu = src_feature.detach().numpy()
    tgt_feature_cpu = tgt_feature.detach().numpy()
    for batch_iter in range(args.batch_size):
        src_batch_sorted = []
        src_batch_feat = src_feature_cpu[batch_iter]
        tgt_batch_feat = tgt_feature_cpu[batch_iter]
        tree = kdtree.KDTree(src_batch_feat)
        for i in range(args.top_k_num):
            dis, pos = tree.query(tgt_batch_feat[i])
            src_batch_sorted.append(src_points[batch_iter][pos])
            if dis <= args.feat_dis_limit:
                valid_list[batch_iter][i] = True
        src_sorted_points.append(torch.stack(src_batch_sorted))
    return torch.stack(src_sorted_points), valid_list


def feat_match(src_feature, src_points, tgt_points, R, t, spare_feat):
    src_points = (torch.matmul(R, src_points) + t.unsqueeze(-1)).permute((0, 2, 1))
    tgt_points = tgt_points.permute(0, 2, 1)
    src_feature_sorted = []
    match_num = []
    for batch_iter in range(src_feature.shape[0]):
        match_batch_num = 0
        tree = kdtree.KDTree(src_points[batch_iter])
        src_feature_batch_sorted = []
        for i in range(tgt_points[batch_iter].__len__()):
            _, match_idx_of_src = tree.query(tgt_points[batch_iter][i], distance_upper_bound=args.max_match_limit)
            if match_idx_of_src == tgt_points[batch_iter].__len__():
                src_feature_batch_sorted.append(spare_feat[batch_iter][i])
            else:
                src_feature_batch_sorted.append(src_feature[batch_iter][match_idx_of_src])
                match_batch_num = match_batch_num + 1
        src_feature_sorted.append(torch.stack(src_feature_batch_sorted))
        match_num.append(match_batch_num)
    return torch.stack(src_feature_sorted), match_num


def get_error(data_pred, data_real):
    if data_pred is None:
        return None
    muse = None
    return muse


def get_r_t(src_total_real_points, tgt_points_sorted, match_list):
    # R, t = self.svd(src_total_real_points, tgt_points_sorted, match_list)
    # attention when get a None point pair
    return None, None


def random_rotation():
    angle = int(random.random() * (args.min_angle - args.max_angle) + args.max_angle)
    angle = np.pi / angle
    angle_x = np.random.uniform() * angle
    angle_y = np.random.uniform() * angle
    angle_z = np.random.uniform() * angle

    cos_x = np.cos(angle_x)
    cos_y = np.cos(angle_y)
    cos_z = np.cos(angle_z)
    sin_x = np.sin(angle_x)
    sin_y = np.sin(angle_y)
    sin_z = np.sin(angle_z)
    Rx = np.array([[1, 0, 0],
                   [0, cos_x, -sin_x],
                   [0, sin_x, cos_x]])
    Ry = np.array([[cos_y, 0, sin_y],
                   [0, 1, 0],
                   [-sin_y, 0, cos_y]])
    Rz = np.array([[cos_z, -sin_z, 0],
                   [sin_z, cos_z, 0],
                   [0, 0, 1]])
    R = Rx.dot(Ry).dot(Rz)
    t = np.random.uniform(-args.max_trans, args.max_trans, size=3)
    euler = np.array([angle_z, angle_y, angle_x])

    return R, t, euler


def ensure_path(path):
    if not isdir(os.path.dirname(path)):
        os.mkdir(os.path.dirname(path))


def ensure_delete(path):
    if isfile(path):
        os.remove(path)


def validate_args():
    if args.raw_sample_num % args.split_block != 0:
        print(f"sample num {args.raw_sample_num} can not to be divisible by split block {args.split_block}")
        sys.exit(1)
    split_number = args.raw_sample_num // args.split_block
    if args.batch_size > split_number:
        print(f"batch size {args.batch_size} can not be bigger than split number {split_number}")
        sys.exit(1)
    if args.top_k_num > args.split_block:
        print(f"top k num {args.top_k_num} can not be bigger than split block {args.split_block}")
        sys.exit(1)


def random_down_sample(point_cloud, goal_num=None):
    if goal_num is None:
        goal_num = pow(2, int(log(point_cloud.__len__(), 2)))
    list0 = random.sample(range(0, point_cloud.__len__()), goal_num)
    args.raw_data_real_size = goal_num
    return point_cloud[list0]


def write_out_txt(data, goal_path):
    data = data.reshape(data.shape[0] * data.shape[1], data.shape[-1])
    if isinstance(data, torch.Tensor):
        data = data.detach().numpy()
    if os.path.isfile(goal_path):
        os.remove(goal_path)
    np.savetxt(goal_path, data)


def neighbour_maker(pcd, knn_num):
    tree = kdtree.KDTree(pcd)
    point_kdtree = []
    for center_point in tqdm(pcd):
        _, neighbour_arr = tree.query(center_point, knn_num + 1, distance_upper_bound=args.knn_dis)
        for neighbour in neighbour_arr:
            if neighbour == pcd.__len__():
                point_kdtree.append(neighbour_arr[0])
            else:
                point_kdtree.append(neighbour)
    return point_kdtree


def get_k_idx(score, k):
    score, score_idx = torch.sort(score, dim=-1, descending=True)
    if args.disable_keypoint:
        score_idx = score_idx[random.sample(range(0, score_idx.__len__()), score_idx.__len__())]
    top_k_idx = score_idx[:, 0:k]
    return top_k_idx


def tensor_rebuild(data, idx):
    # data shape: numpy_B,N,K,3 or tensor_B,N,128
    # idx shape: B,TOP_K
    # return shape: B,TOP_K,K,3 or B,TOP_K,128
    if str(type(data)) == "<class 'torch.Tensor'>":
        tmp_data_block = []
        for i in range(data.shape[0]):
            tmp_data_block.append(data[i, idx[i]])
        tmp_data_block = torch.stack(tmp_data_block)
        return tmp_data_block
    else:
        tmp_data_block = []
        for i in range(data.shape[0]):
            tmp_data_block.append(data[i, idx[i]])
        tmp_data_block = np.asarray(tmp_data_block, dtype=args.numpy_format)
        return tmp_data_block


def feature_fusion(nk256, nk128):
    nk256 = nk256.permute(0, 2, 1)
    nk384 = torch.cat((nk128, nk256), 2)
    return nk384


def seed_everything():
    seed = random.randint(0, 100)
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
