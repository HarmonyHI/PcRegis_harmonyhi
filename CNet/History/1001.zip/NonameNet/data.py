import os.path
import sys
import numpy as np
from torch.utils.data import Dataset
import args
from args import pc_path, knn_num, down_sample_num, data_format, tmp_sampled_knn_path, \
    raw_knn_path, raise_sampled_knn
from utils import o3d_knn_maker, random_down_sample, random_Rotation, \
    Write_out_txt, ensure_path


def get_pointcloud():
    try:
        pc_huge = np.loadtxt(pc_path, dtype=data_format)  # [n, 3]
    except OSError:
        ensure_path(pc_path)
        print(f"{pc_path} is not found, please check")
        sys.exit(1)
    if os.path.isfile(raw_knn_path):
        pc_knn_idx_of_huge = np.load(raw_knn_path, allow_pickle=True)
        if not pc_knn_idx_of_huge.__len__() == (pc_huge.shape[0] * (knn_num + 1)):
            print("knn is broken, rebuilding")
            pc_knn_idx_of_huge = np.asarray(o3d_knn_maker(pc_huge, knn_num))
            np.save(raw_knn_path, pc_knn_idx_of_huge)
        else:
            print("knn loaded from file")
    else:
        print("not found knn, creating")
        pc_knn_idx_of_huge = np.asarray(o3d_knn_maker(pc_huge, knn_num))
        np.save(raw_knn_path, pc_knn_idx_of_huge)
        print("knn saved")
    pc_knn_idx_of_huge = pc_knn_idx_of_huge.reshape(pc_huge.shape[0], knn_num + 1)  # [n, knn_num]
    pc_knn_huge = pc_huge[pc_knn_idx_of_huge]  # [n, knn_num, 3]
    pc_knn_sampled = random_down_sample(pc_knn_huge, down_sample_num)  # [down_sample_num , knn_num + 1 , 3]
    pc_knn_sampled = batch_divider(pc_knn_sampled)  # [b, point_num , knn_num + 1 , 3]
    if raise_sampled_knn:
        Write_out_txt(2, pc_knn_sampled, tmp_sampled_knn_path, "numpy")
    return pc_knn_sampled


def batch_divider(data):
    if data.shape[0] % args.split_number != 0:
        print("sample num can not to be divisible by split num")
        sys.exit(1)
    if args.batch_size > args.split_number:
        print("batch size can not be bigger than split number")
        sys.exit(1)
    data = np.stack(np.split(data, args.split_number))
    return data


class ModelNet40(Dataset):
    def __init__(self, partition='train', gaussian_noise=False, unseen=False):
        super(ModelNet40, self).__init__()
        self.partition = partition
        self.gaussian_noise = gaussian_noise
        self.unseen = unseen
        self.data_knn = get_pointcloud()

    def __getitem__(self, item):
        pointcloud1_knn = self.data_knn[item].transpose(0, 2, 1)
        R_ab, translation_ab, euler_ab = random_Rotation()
        pointcloud2_knn = np.matmul(R_ab, pointcloud1_knn) + translation_ab[:, np.newaxis]
        pointcloud1_knn = np.random.permutation(pointcloud1_knn)
        pointcloud2_knn = np.random.permutation(pointcloud2_knn)
        pointcloud1_knn = pointcloud1_knn.transpose((1, 0, 2))
        pointcloud2_knn = pointcloud2_knn.transpose((1, 0, 2))
        return R_ab.astype(data_format), translation_ab.astype(data_format), \
            euler_ab.astype(data_format), pointcloud1_knn, pointcloud2_knn

    def __len__(self):
        return self.data_knn.shape[0]
