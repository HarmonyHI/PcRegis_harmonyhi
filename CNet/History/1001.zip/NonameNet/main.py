from os.path import isfile
import torch
import args
from torch import optim
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from tqdm import tqdm
from FeatureNet import FeatureNet
from data import ModelNet40
from utils import seed_everything, ensure_path, ensure_delete


def train_one_epoch(model, loader, opt, epoch):
    loss_sum = 0
    difference = 0
    case_num = args.top_k_num * args.split_number
    for R, t, euler, src_knn, tgt_knn in tqdm(loader):
        src_knn = src_knn.cpu()
        tgt_knn = tgt_knn.cpu()
        opt.zero_grad()
        src_feature, tgt_feature, loss = model(src_knn, tgt_knn, R, t)
        difference += torch.sum(abs(tgt_feature))
        loss = loss * (case_num / difference)
        loss.backward(retain_graph=True)
        opt.step()
        loss_sum += loss
    print(f"========== Epoch {epoch + 1} loss {loss_sum / loader.__len__()} abs_sum {difference / case_num} ==========")


def train(network, loader):
    network.train()
    opt = optim.Adam(network.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = MultiStepLR(opt, milestones=args.milestones, gamma=args.gamma)
    for epoch in range(args.epochs):
        train_one_epoch(network, loader, opt, epoch)
        scheduler.step()


def test(network, loader):
    for epoch in range(args.epochs):
        for R, t, euler, src_knn, tgt_knn in tqdm(loader):
            src_knn = src_knn.cpu()
            tgt_knn = tgt_knn.cpu()
            src_feature, tgt_feature = network(src_knn, tgt_knn, R, t)
            print(src_feature, tgt_feature)


if __name__ == '__main__':
    seed_everything(args.random_seed)
    if args.device.type != "cpu":
        print("CUDA ENABLED")
    train_loader = DataLoader(
        ModelNet40(partition=args.partition, gaussian_noise=args.gaussian_noise),
        batch_size=args.batch_size, shuffle=args.shuffle, drop_last=args.drop_last, num_workers=args.num_workers)
    ensure_path(args.net_path)
    if isfile(args.net_path) and not args.is_train:
        print("load net from file")
        m_state_dict = torch.load(args.net_path)
        net = FeatureNet().to(args.device)
        net.load_state_dict(m_state_dict)
        test(net, train_loader)
    else:
        net = FeatureNet().to(args.device)
        torch.save(net.state_dict(), args.net_path)
        train(net, train_loader)
        ensure_delete(args.net_path)
        torch.save(net.state_dict(), args.net_path)
        print("save net successfully")
