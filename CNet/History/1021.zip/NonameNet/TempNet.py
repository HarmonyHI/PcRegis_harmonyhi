import torch
import torch.nn as nn
import torch.nn.functional as F

import args
from utils import feature_fusion, get_k_idx, tensor_rebuild, sp_point_match, get_error, \
    feat_match


class Conv1DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, k_size):
        super(Conv1DBNReLU, self).__init__()
        self.conv = nn.Conv1d(in_channel, out_channel, k_size, bias=False)
        self.bn = nn.BatchNorm1d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv2DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, k_size):
        super(Conv2DBNReLU, self).__init__()
        self.conv = nn.Conv2d(in_channel, out_channel, k_size, bias=False)
        self.bn = nn.BatchNorm2d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv1DBlock(nn.Module):
    def __init__(self, channels, k_size):
        super(Conv1DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv1DBNReLU(channels[i], channels[i + 1], k_size))
        self.conv.append(nn.Conv1d(channels[-2], channels[-1], k_size))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Conv2DBlock(nn.Module):
    def __init__(self, channels, k_size):
        super(Conv2DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv2DBNReLU(channels[i], channels[i + 1], k_size))
        self.conv.append(nn.Conv2d(channels[-2], channels[-1], k_size))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Propagate(nn.Module):
    def __init__(self, in_channel, emb_dims):
        super(Propagate, self).__init__()
        self.conv2d = Conv2DBlock((in_channel, emb_dims, emb_dims), 1)
        self.conv1d = Conv1DBlock((emb_dims, emb_dims), 1)

    def forward(self, x, knn_p):
        x_f = knn_p - x.unsqueeze(-1)
        x_f = x_f.type(args.tensor_format)
        x_f = self.conv2d(x_f)
        x = x_f.max(-1)[0]
        x = self.conv1d(x)
        return x, x_f


class GNN(nn.Module):
    def __init__(self):
        super(GNN, self).__init__()
        self.propagate1 = Propagate(3, 32)
        self.propagate2 = Propagate(32, 64)
        self.propagate3 = Propagate(64, 128)
        self.propagate4 = Propagate(128, 256)

    def forward(self, x_knn):
        x = x_knn[:, :, :, 0:1].squeeze()
        x, x_f = self.propagate1(x, x_knn)
        x, x_f = self.propagate2(x, x_f)
        x, x_f = self.propagate3(x, x_f)
        x, x_f = self.propagate4(x, x_f)
        return x


class GraphAttention(nn.Module):
    def __init__(self, all_channel, feature_dim, dropout, alpha):
        super(GraphAttention, self).__init__()
        self.alpha = alpha
        self.a = nn.Parameter(torch.zeros(size=(all_channel, feature_dim)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)
        self.dropout = dropout
        self.leaky_relu = nn.LeakyReLU(self.alpha)

    def forward(self, center_xyz, center_feature, grouped_xyz, grouped_feature):
        """
        Input:
            center_xyz: sampled points position data [B, n_point, C]
            center_feature: centered point feature [B, n_point, D]
            grouped_xyz: group xyz data [B, n_point, n_sample, C]
            grouped_feature: sampled points feature [B, n_point, n_sample, D]
        Return:
            graph_pooling: results of graph pooling [B, n_point, D]
        """
        B, n_point, C = center_xyz.size()
        _, _, n_sample, D = grouped_feature.size()
        delta_p = center_xyz.view(B, n_point, 1, C).expand(B, n_point, n_sample,
                                                           C) - grouped_xyz  # [B, n_point, n_sample, C]
        delta_h = center_feature.view(B, n_point, 1, D).expand(B, n_point, n_sample,
                                                               D) - grouped_feature  # [B, n_point, n_sample, D]
        delta_p_concat_h = torch.cat([delta_p, delta_h], dim=-1)  # [B, n_point, n_sample, C+D]
        e = self.leaky_relu(torch.matmul(delta_p_concat_h, self.a))  # [B, n_point, n_sample,D]
        attention = F.softmax(e, dim=2)  # [B, n_point, n_sample,D]
        attention = F.dropout(attention, self.dropout, training=self.training)
        graph_pooling = torch.sum(torch.mul(attention, grouped_feature), dim=2)  # [B, n_point, D]
        return graph_pooling


class CircleLoss(nn.Module):
    def __init__(self, m, gamma):
        super(CircleLoss, self).__init__()
        self.m = m
        self.gamma = gamma
        self.soft_plus = nn.Softplus()

    def forward(self, margin, positive, negative):
        sp = 1 / (F.pairwise_distance(margin, positive) + 1)
        sn = 1 / (F.pairwise_distance(margin, negative) + 1)
        ap = torch.clamp_min(- sp.detach() + 1 + self.m, min=0.)
        an = torch.clamp_min(sn.detach() + self.m, min=0.)
        delta_p = 1 - self.m
        delta_n = self.m
        logit_p = - ap * (sp - delta_p) * self.gamma
        logit_n = an * (sn - delta_n) * self.gamma
        loss = self.soft_plus(torch.logsumexp(logit_n, dim=0) + torch.logsumexp(logit_p, dim=0))
        return loss


class KeypointDetector(nn.Module):
    def __init__(self, out):
        super(KeypointDetector, self).__init__()
        self.knn_num = args.knn_num
        self.conv1 = nn.Conv2d(10, out[0], kernel_size=1)
        self.bn1 = nn.BatchNorm2d(out[0], eps=1e-6, momentum=0.01)
        self.conv2 = nn.Conv2d(out[0], out[1], kernel_size=1)
        self.bn2 = nn.BatchNorm2d(out[1], eps=1e-6, momentum=0.01)
        self.conv3 = nn.Conv2d(out[1], out[2], kernel_size=1)
        self.bn3 = nn.BatchNorm2d(out[2], eps=1e-6, momentum=0.01)
        self.pool3 = AttentivePooling(out[2], out[2])
        self.mlp = MLP()

    def forward(self, point_cloud, pc_knn):
        xyz = self.relative_pos_encoding(point_cloud, pc_knn)
        xyz = F.leaky_relu(self.bn1(self.conv1(xyz.to(torch.float32))), negative_slope=0.2)
        xyz = F.leaky_relu(self.bn2(self.conv2(xyz)), negative_slope=0.2)
        xyz = F.leaky_relu(self.bn3(self.conv3(xyz)), negative_slope=0.2)
        xyz = self.pool3(xyz).squeeze(-1)
        N128 = xyz
        N128 = N128.permute(0, 2, 1)
        score = self.mlp(xyz)
        score = score.permute(0, 2, 1)
        score = score.squeeze(-1)
        loss = 0
        return score, N128, loss

    def relative_pos_encoding(self, xyz, neighbor_xyz):
        neighbor_xyz = neighbor_xyz.permute(0, 3, 1, 2).contiguous()
        xyz = xyz[:, :, None, :].permute(0, 3, 1, 2).contiguous()
        repeated_xyz = xyz.repeat(1, 1, 1, self.knn_num)
        relative_xyz = repeated_xyz - neighbor_xyz
        relative_dist = torch.sqrt(torch.sum(relative_xyz ** 2, dim=1, keepdim=True))
        relative_feature = torch.cat([relative_dist, relative_xyz, repeated_xyz, neighbor_xyz], dim=1) \
            .to(args.tensor_format)
        return relative_feature


class AttentivePooling(nn.Module):
    def __init__(self, n_feature, d_out):
        super().__init__()
        self.n_feature = n_feature
        self.fc1 = nn.Linear(n_feature, n_feature, bias=False)
        self.conv1 = nn.Conv2d(n_feature, d_out, kernel_size=1)
        self.bn1 = nn.BatchNorm2d(d_out, eps=1e-6, momentum=0.01)

    def forward(self, x):
        batch_size = x.shape[0]
        num_points = x.shape[2]
        num_neigh = x.shape[3]
        x = x.permute(0, 2, 3, 1).contiguous()
        x = torch.reshape(x, [-1, num_neigh, self.n_feature])
        att_activation = self.fc1(x)
        att_score = F.softmax(att_activation, dim=1)
        x = x * att_score
        x = torch.sum(x, dim=1)
        x = torch.reshape(x, [batch_size, num_points, self.n_feature])[:, :, :, None].permute(0, 2, 1,
                                                                                              3).contiguous()
        x = F.leaky_relu(self.bn1(self.conv1(x)), negative_slope=0.2)
        return x


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(128, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.fc3(x)
        x = self.relu(x)
        x = x.permute(0, 2, 1)
        return x


class SVDHead(nn.Module):
    def __init__(self):
        super(SVDHead, self).__init__()
        self.reflect = nn.Parameter(torch.eye(3), requires_grad=False)
        self.reflect[2, 2] = -1

    def forward(self, src, src_corr, weights):
        src_centered = src - src.mean(dim=2, keepdim=True)
        src_corr_centered = src_corr - src_corr.mean(dim=2, keepdim=True)
        H = torch.matmul(src_centered * weights.unsqueeze(1), src_corr_centered.transpose(2, 1).contiguous())
        R = []
        for i in range(src.size(0)):
            u, s, v = torch.svd(H[i])
            r = torch.matmul(v, u.transpose(1, 0).contiguous())
            r_det = torch.det(r)
            if r_det < 0:
                u, s, v = torch.svd(H[i])
                v = torch.matmul(v, self.reflect)
                r = torch.matmul(v, u.transpose(1, 0).contiguous())
            R.append(r)
        R = torch.stack(R, dim=0)
        t = torch.matmul(-R, (weights.unsqueeze(1) * src).sum(dim=2, keepdim=True)) + (
                weights.unsqueeze(1) * src_corr).sum(dim=2, keepdim=True)
        return R, t.view(src.size(0), 3)


class TempNet(nn.Module):
    def __init__(self):
        super(TempNet, self).__init__()
        self.keypoint_detector = KeypointDetector([32, 64, 128])
        self.emb_nn = GNN()
        self.fc1 = nn.Linear(384, 512, bias=False)
        self.fc2 = nn.Linear(512, 256, bias=False)
        self.fc3 = nn.Linear(256, 128, bias=False)
        self.circle_loss = CircleLoss(m=0.25, gamma=256)
        self.svd = SVDHead()

    def forward(self, src_knn, tgt_knn, rot_real=None, trans_real=None):
        with torch.no_grad():
            src_knn = src_knn.to(args.device).permute((0, 1, 3, 2))
            tgt_knn = tgt_knn.to(args.device).permute((0, 1, 3, 2))
            sp_index_src, nk128_src, super_loss_src = self.get_super_index(src_knn[:, :, 0, :], src_knn[:, :, 1::, :])
            sp_index_tgt, nk128_tgt, super_loss_tgt = self.get_super_index(tgt_knn[:, :, 0, :], tgt_knn[:, :, 1::, :])
            src_knn = tensor_rebuild(src_knn, sp_index_src).permute((0, 3, 1, 2))
            tgt_knn = tensor_rebuild(tgt_knn, sp_index_tgt).permute((0, 3, 1, 2))
        src_feat = feature_fusion(self.emb_nn(src_knn), nk128_src)
        tgt_feat = feature_fusion(self.emb_nn(tgt_knn), nk128_tgt)
        src_feat = self.fc3(self.fc2(self.fc1(src_feat)))
        tgt_feat = self.fc3(self.fc2(self.fc1(tgt_feat)))
        src_xyz = src_knn[:, :, :, 0]
        tgt_xyz = tgt_knn[:, :, :, 0]
        src_xyz_corr, valid_list = sp_point_match(src_xyz, src_feat, tgt_feat)
        rot_pred, trans_pred = self.get_r_t(src_xyz_corr, tgt_xyz, valid_list)
        rot_error = get_error(rot_pred, rot_real)
        trans_error = get_error(trans_pred, trans_real)
        if args.is_train:
            loss = self.get_loss(src_feat, tgt_feat, src_xyz, tgt_xyz, rot_real, trans_real)
            loss = loss + super_loss_src + super_loss_tgt
            return rot_real, rot_pred, rot_error, trans_real, trans_pred, trans_error, loss
        else:
            return rot_real, rot_pred, rot_error, trans_real, trans_pred, trans_error

    @staticmethod
    def get_loss(src_feat, tgt_feat, src_xyz, tgt_xyz, R, t):
        src_feat_unsort = src_feat
        src_feat, valid_list = feat_match(src_feat, src_xyz, tgt_xyz, R, t, tgt_feat)
        loss = torch.triplet_margin_loss(src_feat, tgt_feat, src_feat_unsort)
        loss = loss.sum() / (args.batch_size * (sum(valid_list) / args.top_k_num))
        return loss

    def get_super_index(self, pc, pc_kdtree):
        score, n128, loss = self.keypoint_detector(pc, pc_kdtree)
        sp_index = get_k_idx(score, args.top_k_num)
        nk128 = tensor_rebuild(n128, sp_index)
        return sp_index, nk128, loss

    @staticmethod
    def get_r_t(src_total_real_points, tgt_points_sorted, match_list):
        # R, t = self.svd(src_total_real_points, tgt_points_sorted, match_list)
        # attention when get a None point pair
        return None, None
