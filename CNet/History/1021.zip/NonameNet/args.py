import os
import torch


is_train = True
raise_sampled_knn = False
raise_sampled_knn_super = True
print_debug_info = False
gaussian_noise = False
shuffle = True
drop_last = True
disable_keypoint = True
max_match_limit = 5e-5
feat_dis_limit = 1
margin = 0.4
p = 2
raw_sample_num = 4096
raw_data_real_size = None
split_block = 512
batch_size = 8
knn_num = 64
knn_dis = 0.8
top_k_num = 512
epochs = 100
min_angle = 10
max_angle = 7
max_trans = 0.05
random_seed = 50
num_workers = 2
learn_rate = 0.001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
negative_point_distance = 2
device = torch.device("cpu" if torch.cuda.is_available() else "cpu")
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLOUD_DIR = BASE_DIR + "/PointCloudDir/"
net_path = BASE_DIR + "/saved_net/NonameNet.pkl"
pc_file_name = "campus_down_sample"
pc_path = CLOUD_DIR + pc_file_name + ".txt"
tmp_sampled_knn_super_path = CLOUD_DIR + "tmp_sampled_knn_super.txt"
raw_knn_path = CLOUD_DIR + f"knn_{knn_num}_{knn_dis}_{pc_file_name}.npy"
numpy_format = 'float32'
tensor_format = torch.float32
reduction = 'mean'
