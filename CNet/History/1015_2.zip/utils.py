import os
import random
import sys
from math import log
from os.path import isdir, isfile
import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import torch
from tqdm import tqdm
import args


def sp_point_match(tgt_points, src_feature, tgt_feature):
    tgt_sorted_points = tgt_points
    # if pair distance more than number, append None
    return tgt_sorted_points


def feat_match(src_feature, src_points, tgt_points, R, t, spare_feat):
    src_points = (torch.matmul(R, src_points) + t.unsqueeze(-1)).permute((0, 2, 1))
    tgt_points = tgt_points.permute(0, 2, 1)
    src_feature_sorted = []
    match_num = []
    for batch_iter in range(src_feature.shape[0]):
        match_batch_num = 0
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(src_points[batch_iter])
        src_tree = o3d.geometry.KDTreeFlann(pcd)
        src_feature_batch_sorted = []
        for i in range(tgt_points[batch_iter].__len__()):
            B_corr_idx_of_A = src_tree.search_hybrid_vector_3d(tgt_points[batch_iter][i], args.max_match_limit, 1)[1]
            if B_corr_idx_of_A.__len__() == 0:
                src_feature_batch_sorted.append(spare_feat[batch_iter][i])
            else:
                print(f"pair{tgt_points[batch_iter][i]} {src_points[batch_iter][B_corr_idx_of_A[0]]} ,pair_dis = {torch.nn.functional.pairwise_distance(tgt_points[batch_iter][i], src_points[batch_iter][B_corr_idx_of_A[0]])}, rand_dis = {torch.nn.functional.pairwise_distance(tgt_points[batch_iter][i], src_points[batch_iter][random.randint(0, src_points[batch_iter].__len__()-1)])}")
                src_feature_batch_sorted.append(src_feature[batch_iter][B_corr_idx_of_A[0]])
                match_batch_num = match_batch_num + 1
        src_feature_sorted.append(torch.stack(src_feature_batch_sorted))
        match_num.append(match_batch_num)
    return torch.stack(src_feature_sorted), match_num


def get_error(data_pred, data_real):
    if data_pred is None:
        return None
    muse = None
    return muse


def random_rotation():
    angle = int(random.random() * (args.min_angle - args.max_angle) + args.max_angle)
    angle = np.pi / angle
    angle_x = np.random.uniform() * angle
    angle_y = np.random.uniform() * angle
    angle_z = np.random.uniform() * angle

    cos_x = np.cos(angle_x)
    cos_y = np.cos(angle_y)
    cos_z = np.cos(angle_z)
    sin_x = np.sin(angle_x)
    sin_y = np.sin(angle_y)
    sin_z = np.sin(angle_z)
    Rx = np.array([[1, 0, 0],
                   [0, cos_x, -sin_x],
                   [0, sin_x, cos_x]])
    Ry = np.array([[cos_y, 0, sin_y],
                   [0, 1, 0],
                   [-sin_y, 0, cos_y]])
    Rz = np.array([[cos_z, -sin_z, 0],
                   [sin_z, cos_z, 0],
                   [0, 0, 1]])
    R = Rx.dot(Ry).dot(Rz)
    t = np.random.uniform(-args.max_trans, args.max_trans, size=3)
    euler = np.array([angle_z, angle_y, angle_x])

    return R, t, euler


def ensure_path(path):
    if not isdir(os.path.dirname(path)):
        os.mkdir(os.path.dirname(path))


def ensure_delete(path):
    if isfile(path):
        os.remove(path)


def random_down_sample(point_cloud, goal_num=None):
    if goal_num is None:
        goal_num = pow(2, int(log(point_cloud.__len__(), 2)))
    list0 = random.sample(range(0, point_cloud.__len__()), goal_num)
    return point_cloud[list0]


def write_out_txt(dimension, data, goal_path, typ):
    if os.path.isfile(goal_path):
        os.remove(goal_path)
    io = IOStream(goal_path)
    if typ != "numpy":
        np_data = data.detach().cpu().numpy()
    else:
        np_data = data
    if dimension == 1:
        for i in range(np_data.__len__()):
            io.println(str(np_data[i]).replace('[', '').replace(']', ''))
    elif dimension == 2:
        for i in range(np_data.__len__()):
            for ii in range(np_data[i].__len__()):
                io.print(str(np_data[i][ii]).replace('[', '').replace(']', ''))
                io.ln()


def o3d_knn_maker(point_cloud, ran):
    point_cloud = np.array(point_cloud)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(point_cloud)
    pc_tree = o3d.geometry.KDTreeFlann(pcd)
    kdtree = []
    for i in tqdm(range(pcd.points.__len__())):
        tmp_data = pc_tree.search_knn_vector_3d(pcd.points[i], ran + 1)[1]
        for ii in range(tmp_data.__len__()):
            kdtree.append(tmp_data[ii])
    return kdtree


def get_k_idx(score, k):
    score, score_idx = torch.sort(score, dim=-1, descending=True)
    if args.disable_keypoint:
        score_idx = score_idx[:, torch.randperm(score_idx.size(1))]
    top_k_idx = score_idx[:, 0:k]
    return top_k_idx


def tensor_rebuild(data, idx):
    # data shape: numpy_B,N,K,3 or tensor_B,N,128
    # idx shape: B,TOP_K
    # return shape: B,TOP_K,K,3 or B,TOP_K,128
    if str(type(data)) == "<class 'torch.Tensor'>":
        tmp_data_block = []
        for i in range(data.shape[0]):
            tmp_data_block.append(data[i, idx[i]])
        tmp_data_block = torch.stack(tmp_data_block)
        return tmp_data_block
    else:
        tmp_data_block = []
        for i in range(data.shape[0]):
            tmp_data_block.append(data[i, idx[i]])
        tmp_data_block = np.asarray(tmp_data_block, dtype=args.numpy_format)
        return tmp_data_block


def feature_fusion(nk256, nk128):
    nk256 = nk256.permute(0, 2, 1)
    nk384 = torch.cat((nk128, nk256), 2)
    return nk384


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


class IOStream:
    def __init__(self, path):
        self.f = open(path, 'a')

    def cprint(self, text):
        self.f.write(text + '\n')
        self.f.flush()

    def close(self):
        self.f.close()

    def print(self, text):
        self.f.write(text + " ")
        self.f.flush()

    def ln(self):
        self.f.write('\n')
        self.f.flush()

    def println(self, text):
        self.f.write(text + '\n')
        self.f.flush()


def jitter_point_cloud(point_cloud, sigma=0.01, clip=0.05):
    N, C = point_cloud.shape
    point_cloud = point_cloud + np.clip(sigma * np.random.randn(N, C), -1 * clip, clip)
    return point_cloud


def visualization(points1, points2):
    skip = 1
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    point_range = range(0, points1.shape[0], skip)
    x = points1[point_range, 0]
    y = points1[point_range, 1]
    z = points1[point_range, 2]
    ax.scatter(x, y, z, c='g', cmap='Blues', marker="o")
    ax.axis('auto')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('feature visualization')

    point_range = range(0, points2.shape[0], skip)
    x = points2[point_range, 0]
    y = points2[point_range, 1]
    z = points2[point_range, 2]
    ax.scatter(x, y, z, c='r', cmap='Blues', marker="o")
    ax.axis('auto')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('feature visualization')

    ax.axis('off')
    ax.grid(False)
    plt.show()


class UnPairException(Exception):
    def __init__(self, limit_distance, distance):
        self.limit_distance = limit_distance
        self.distance = distance

    def to_string(self):
        return f"limit distance is {self.limit_distance},however now is {self.distance}"
