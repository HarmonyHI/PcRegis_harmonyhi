import sys
from os.path import isfile
import torch
import args
from torch import optim
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from tqdm import tqdm
import utils
from TempNet import TempNet
from data import WhuDataset
from utils import seed_everything, ensure_path, ensure_delete
import os


def train_one_epoch(model, loader, opt):
    loss_sum = 0
    rot_error_sum = 0
    trans_error_sum = 0
    for src_knn, tgt_knn, R, t in tqdm(loader):
        opt.zero_grad()
        R_pred, t_pred, loss = model(src_knn, tgt_knn, R, t)
        rot_error = utils.get_error(R_pred, R)
        trans_error = utils.get_error(t_pred, t)
        loss.backward()
        opt.step()
        loss_sum += loss
        rot_error_sum += rot_error
        trans_error_sum += trans_error
        print(f"point match {args.point_match_info} feat match {args.feat_match_info}")
    return loss_sum, rot_error_sum, trans_error_sum


def train(net, loader):
    net.train()
    opt = optim.Adam(net.parameters(), lr=args.learn_rate, weight_decay=args.weight_decay)
    scheduler = MultiStepLR(opt, milestones=args.milestones, gamma=args.gamma)
    for epoch in range(args.epochs):
        args.now_epoch = epoch
        loss_sum, rot_err, trans_err = train_one_epoch(net, loader, opt)
        print(f"========== Epoch {epoch + 1} loss {loss_sum / loader.__len__()}==========")
        scheduler.step()


def test(net, loader):
    net.eval()
    for epoch in range(args.epochs):
        for src_knn, tgt_knn, R, t in tqdm(loader):
            R_pred, t_pred = net(src_knn, tgt_knn, R, t)
            print(R, R_pred, t, t_pred)


def main():
    if args.device.type != "cpu":
        print("CUDA ENABLED")
    ensure_path(args.net_path)
    net = TempNet().to(device=args.device, dtype=args.tensor_format)
    if args.do_train:
        train_dataset = WhuDataset(partition='train', gaussian_noise=args.gaussian_noise, unseen=args.unseen)
        train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=args.shuffle,
                                  drop_last=args.drop_last,
                                  num_workers=args.num_workers)
        print("train begin")
        train(net, train_loader)
        ensure_delete(args.net_path)
        torch.save(net.state_dict(), args.net_path)
        print("save net successfully")
    if args.do_test:
        if not isfile(args.net_path):
            print("not found saved net")
            sys.exit(0)
        args.do_train = False
        test_dataset = WhuDataset(partition='test', gaussian_noise=args.gaussian_noise, unseen=args.unseen)
        test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=args.shuffle,
                                 drop_last=args.drop_last,
                                 num_workers=args.num_workers)
        m_state_dict = torch.load(args.net_path)
        net.load_state_dict(m_state_dict)
        print("test begin")
        test(net, test_loader)


if __name__ == '__main__':
    seed_everything()
    os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
    utils.validate_args()
    main()
