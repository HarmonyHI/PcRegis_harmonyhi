import torch
from utils import to_md5

do_train = True
do_test = False
disable_keypoint = False
gaussian_noise = False
unseen = False
shuffle = True
drop_last = True
last_loss = None
point_match_info = None
feat_match_info = None
now_epoch = None
output_epoch = 80
raw_sample_num = 65536
split_block = 4096
batch_size = 4
epochs = 200
max_match_limit = 0.8
feat_dis_limit = 0.5
margin = 0.4
p = 2
knn_num = 64
knn_dis = 0.8
top_k_num = 2048
num_workers = 2
learn_rate = 0.001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
device = torch.device("cpu" if torch.cuda.is_available() else "cpu")
numpy_format = 'float32'
tensor_format = torch.float32
reduction = 'mean'

junk_dir = "F:\\code_junk\\"
src_path = "F:\\WHU\\WHU_dir\\6-Campus\\9.txt"
tgt_path = "F:\\WHU\\WHU_dir\\6-Campus\\10.txt"
rt_path = "F:\\WHU\\WHU_dir\\6-Campus\\9-10\\transformation.txt"

src_knn_file_name = to_md5(src_path[-9::] + str(knn_num) + str(knn_dis))[0:15]
tgt_knn_file_name = to_md5(tgt_path[-9::] + str(knn_num) + str(knn_dis))[0:15]
net_path = junk_dir + "saved_net.torchnet"
src_knn_path = junk_dir + f"knn_{src_knn_file_name}.npy"
tgt_knn_path = junk_dir + f"knn_{tgt_knn_file_name}.npy"
