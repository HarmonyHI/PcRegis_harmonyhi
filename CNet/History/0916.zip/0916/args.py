import os

import torch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))
raise_sampled_knn = True
raise_sampled_knn_super = True
is_train = True
gaussian_noise = False
shuffle = True
drop_last = True
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
pc_path = PARENT_DIR + '/PointCloudDir/' + "1" + ".txt"
tmp_sampled_knn_super_path = PARENT_DIR + '/PointCloudDir/' + "tmp_sampled_knn_super" + ".txt"
tmp_sampled_knn_path = PARENT_DIR + '/PointCloudDir/' + "tmp_sampled_knn" + ".txt"
raw_knn_path = PARENT_DIR + '/PointCloudDir/' + "raw_knn" + ".npy"
net_path = BASE_DIR + '/saved_net/' + "0916" + ".pkl"
data_format = 'float32'
reduction = 'mean'
partition = 'train'
margin = 0.4
p = 2
down_sample_num = 8192
knn_num = 64
top_k_num = 500
tile_number = 1
batch_size = 1
epochs = 50
max_angle = 5
min_angle = 2
random_seed = 50
positive_num = 1
negative_num = 4
num_workers = 2
lr = 0.0001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
