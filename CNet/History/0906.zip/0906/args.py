import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(os.path.dirname(BASE_DIR))
pc_path = PARENT_DIR + '/PointCloudDir/' + "1" + ".txt"
net_path = BASE_DIR + '/saved_net/' + "0906" + ".pkl"
is_train = True
margin = 0.4
p = 2
data_format = 'float32'
reduction = 'mean'
down_sample_num = 8000
knn_num = 64
top_k_num = 50
tile_number = 8
batch_size = 4
epochs = 5
gaussian_noise = False
max_angle = 5
min_angle = 2
random_seed = 50
positive_num = 1
negative_num = 4
