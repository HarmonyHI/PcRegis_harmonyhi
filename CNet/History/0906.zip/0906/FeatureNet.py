import torch
import torch.nn as nn
import args
from util import get_corresponding_relation


class Conv1DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, ksize):
        super(Conv1DBNReLU, self).__init__()
        self.conv = nn.Conv1d(in_channel, out_channel, ksize, bias=False)
        self.bn = nn.BatchNorm1d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv2DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, ksize):
        super(Conv2DBNReLU, self).__init__()
        self.conv = nn.Conv2d(in_channel, out_channel, ksize, bias=False)
        self.bn = nn.BatchNorm2d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv1DBlock(nn.Module):
    def __init__(self, channels, ksize):
        super(Conv1DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv1DBNReLU(channels[i], channels[i + 1], ksize))
        self.conv.append(nn.Conv1d(channels[-2], channels[-1], ksize))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Conv2DBlock(nn.Module):
    def __init__(self, channels, ksize):
        super(Conv2DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv2DBNReLU(channels[i], channels[i + 1], ksize))
        self.conv.append(nn.Conv2d(channels[-2], channels[-1], ksize))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Propagate(nn.Module):
    def __init__(self, in_channel, emb_dims):
        super(Propagate, self).__init__()
        self.conv2d = Conv2DBlock((in_channel, emb_dims, emb_dims), 1)
        self.conv1d = Conv1DBlock((emb_dims, emb_dims), 1)

    def forward(self, x, knn_p):
        x_f = knn_p - x.unsqueeze(-1)  # [B, c, N, k] - [B, c, N, 1] = [B, c, N, k]
        x_f = x_f.type(torch.float32)
        x_f = self.conv2d(x_f)  # [B, emb_dims, N, k]
        x = x_f.max(-1)[0]  # [B, C, N]
        x = self.conv1d(x)
        return x, x_f


class GNN(nn.Module):
    def __init__(self):
        super(GNN, self).__init__()
        self.propagate1 = Propagate(3, 32)
        self.propagate2 = Propagate(32, 64)
        self.propagate3 = Propagate(64, 128)
        self.propagate4 = Propagate(128, 256)

    def forward(self, x_knn):
        x = x_knn[:, :, :, 0:1].squeeze()
        x, x_f = self.propagate1(x, x_knn)
        x, x_f = self.propagate2(x, x_f)
        x, x_f = self.propagate3(x, x_f)
        x, x_f = self.propagate4(x, x_f)
        return x


class FeatureNet(nn.Module):
    def __init__(self):
        super(FeatureNet, self).__init__()
        self.fc1 = nn.Linear(384, 512, bias=False)
        self.fc2 = nn.Linear(512, 256, bias=False)
        self.fc3 = nn.Linear(256, 128, bias=False)
        self.emb_nn = GNN()
        self.triplet_loss = nn.TripletMarginLoss(margin=args.margin, p=args.p, reduction=args.reduction)

    @staticmethod
    def feature_fusion(nk256, nk128):
        nk256 = nk256.permute(0, 2, 1)
        nk384 = torch.cat((nk128, nk256), 2)
        return nk384

    def forward(self, src_knn, tgt_knn, nk128, R, t):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        src_knn = src_knn.to(device)
        tgt_knn = tgt_knn.to(device)
        src_embedding = self.emb_nn(src_knn)
        tgt_embedding = self.emb_nn(tgt_knn)
        src_fusion_feature = self.feature_fusion(src_embedding, nk128)
        tgt_fusion_feature = self.feature_fusion(tgt_embedding, nk128)
        src_feature = self.fc1(src_fusion_feature)
        src_feature = self.fc2(src_feature)
        src_feature = self.fc3(src_feature)
        tgt_feature = self.fc1(tgt_fusion_feature)
        tgt_feature = self.fc2(tgt_feature)
        tgt_feature = self.fc3(tgt_feature)
        loss_arr = []
        for batch_iter in range(src_knn.size(0)):
            src_real_point = src_knn[batch_iter, :, :, 0]
            tgt_real_point = tgt_knn[batch_iter, :, :, 0]
            positive_data, negative_data = get_corresponding_relation(src_real_point, tgt_real_point,
                                                                      R[batch_iter], t[batch_iter])
            for i in range(src_feature[batch_iter].size(0)):
                for positive_data_one_step_iter in positive_data[i]:
                    for negative_data_one_step_iter in negative_data[i]:
                        loss_arr.append(self.triplet_loss(src_feature[batch_iter][i],
                                                          tgt_feature[batch_iter, positive_data_one_step_iter],
                                                          tgt_feature[batch_iter, negative_data_one_step_iter]))
        return src_feature, tgt_feature, loss_arr
