from os.path import isfile
import torch
from torch import optim
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from tqdm import tqdm
from FeatureNet import FeatureNet
from args import epochs, batch_size, gaussian_noise, net_path, is_train, random_seed
from data import ModelNet40
from util import seed_everything, ensure_path, ensure_delete


def train_one_epoch(model, loader, opt, epoch):
    loss_sum = 0
    for R, t, euler, src_knn, tgt_knn, nk128 in tqdm(loader):
        src_knn = src_knn.cpu()
        tgt_knn = tgt_knn.cpu()
        opt.zero_grad()
        src_feature, tgt_feature, loss_arr = model(src_knn, tgt_knn, nk128, R, t)
        loss_sum = sum(loss_arr)
        for point_loss in loss_arr:
            point_loss.backward(retain_graph=True)
        opt.step()
    print(f"========== Epoch {epoch} rank {loss_sum}==============")


def train(network, loader):
    network.train()
    opt = optim.Adam(network.parameters(), lr=0.0001, weight_decay=0.001)
    scheduler = MultiStepLR(opt, milestones=[40, 85], gamma=0.1)
    for epoch in range(epochs):
        train_one_epoch(network, loader, opt, epoch)
        scheduler.step()


if __name__ == '__main__':
    seed_everything(random_seed)
    train_loader = DataLoader(
        ModelNet40(partition='train', gaussian_noise=gaussian_noise),
        batch_size=batch_size, shuffle=True, drop_last=True, num_workers=8)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    ensure_path(net_path)
    if is_train and isfile(net_path):
        print("load net from file")
        m_state_dict = torch.load(net_path)
        net = FeatureNet().to(device)
        net.load_state_dict(m_state_dict)
        train(net, train_loader)
    else:
        ensure_delete(net_path)
        net = FeatureNet().to(device)
        train(net, train_loader)
        torch.save(net.state_dict(), net_path)
        print("save net successfully")
