import numpy as np
from torch.utils.data import Dataset
from args import pc_path, knn_num, tile_number, down_sample_num, data_format
from keypoint import get_super_points
from util import point_transpose, o3d_knn_maker, random_down_sample, get_angle, random_Rotation


def get_pointcloud():
    pc_huge = np.loadtxt(pc_path, dtype=data_format)
    pc_raw = random_down_sample(pc_huge, down_sample_num)
    print("creating knn")
    pc_knn_idx = np.asarray(o3d_knn_maker(pc_raw, knn_num))
    pc_knn_idx = pc_knn_idx.reshape(int(pc_knn_idx.shape[0] / knn_num), knn_num)
    print("choosing keypoint")
    Sp_index, NK128 = get_super_points(pc_raw, pc_knn_idx)
    pc_knn = pc_raw[pc_knn_idx]
    pc_knn = pc_knn[Sp_index, :, :]
    pc_knn = np.tile(pc_knn, (tile_number, 1, 1, 1))
    print("data ready")
    return pc_knn, NK128


class ModelNet40(Dataset):
    def __init__(self, partition='train', gaussian_noise=False, unseen=False):
        super(ModelNet40, self).__init__()
        self.partition = partition
        self.gaussian_noise = gaussian_noise
        self.unseen = unseen
        self.data_knn, self.nk128 = get_pointcloud()

    def __getitem__(self, item):
        pointcloud1_knn = self.data_knn[item].transpose(0, 2, 1)
        R_ab, translation_ab, euler_ab = random_Rotation(np.pi / get_angle())
        pointcloud2_knn = np.matmul(R_ab, pointcloud1_knn) + translation_ab[:, np.newaxis]
        pointcloud1_knn = np.random.permutation(pointcloud1_knn)
        pointcloud2_knn = np.random.permutation(pointcloud2_knn)
        pointcloud1_knn, pointcloud2_knn = point_transpose(pointcloud1_knn, pointcloud2_knn)
        return R_ab.astype(data_format), translation_ab.astype(data_format), \
            euler_ab.astype(data_format), pointcloud1_knn, pointcloud2_knn, self.nk128

    def __len__(self):
        return self.data_knn.shape[0]
