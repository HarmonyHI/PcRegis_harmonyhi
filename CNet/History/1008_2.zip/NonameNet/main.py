from os.path import isfile

import torch
from torch import optim
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from tqdm import tqdm

import args
from TempNet import TempNet
from data import PointCloudDataset
from utils import seed_everything, ensure_path, ensure_delete


def train_one_epoch(model, data, opt, epoch):
    loss_sum = 0
    for R, t, euler, src_knn, tgt_knn in tqdm(data):
        R = R.to(device=args.device)
        t = t.to(device=args.device)
        src_knn = src_knn.to(device=args.device)
        tgt_knn = tgt_knn.to(device=args.device)
        opt.zero_grad()
        R, R_pred, R_muse, t, t_pred, t_muse, loss = model(src_knn, tgt_knn, R, t)
        loss.backward()
        opt.step()
        loss_sum += loss
    print(f"========== Epoch {epoch + 1} loss {loss_sum / data.__len__()}==========")


def train(network, data):
    network.train()
    opt = optim.Adam(network.parameters(), lr=args.learn_rate, weight_decay=args.weight_decay)
    scheduler = MultiStepLR(opt, milestones=args.milestones, gamma=args.gamma)
    for epoch in range(args.epochs):
        train_one_epoch(network, data, opt, epoch)
        scheduler.step()


def test(network, data):
    for epoch in range(args.epochs):
        for R, t, euler, src_knn, tgt_knn in tqdm(data):
            R, R_pred, R_muse, t, t_pred, t_muse = network(src_knn, tgt_knn, R, t)
            print(R, R_pred, R_muse, t, t_pred, t_muse)


if __name__ == '__main__':
    seed_everything(args.random_seed)
    if args.device.type != "cpu":
        print("CUDA ENABLED")
    ensure_path(args.net_path)

    if isfile(args.net_path) and not args.is_train:
        dataset = PointCloudDataset(partition='train', gaussian_noise=args.gaussian_noise)
        loader = DataLoader(
            dataset=dataset, batch_size=args.batch_size, shuffle=args.shuffle,
            drop_last=args.drop_last, num_workers=args.num_workers)
        print("load net from file")
        m_state_dict = torch.load(args.net_path)
        net = TempNet().to(device=args.device, dtype=args.tensor_format)
        net.load_state_dict(m_state_dict)
        test(net, loader)
    else:
        dataset = PointCloudDataset(partition='train', gaussian_noise=args.gaussian_noise)
        dataloader = DataLoader(
            dataset=dataset, batch_size=args.batch_size, shuffle=args.shuffle,
            drop_last=args.drop_last, num_workers=args.num_workers)
        net = TempNet().to(device=args.device, dtype=args.tensor_format)
        torch.save(net.state_dict(), args.net_path)
        train(net, dataloader)
        ensure_delete(args.net_path)
        torch.save(net.state_dict(), args.net_path)
        print("save net successfully")
