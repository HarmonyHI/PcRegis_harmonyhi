import heapq
import os
import random
from os.path import isdir, isfile
import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import torch
import torch.nn.functional as nn_func
from tqdm import tqdm
import args


def get_distance_sorted_idx(center, data_list):
    distance_list = []
    for goal_data in data_list:
        distance_list.append(nn_func.pairwise_distance(center, goal_data))
    arr_min = heapq.nsmallest(5, distance_list)
    index_min = list(map(distance_list.index, arr_min))
    if distance_list[index_min[0]] > args.max_match_limit:
        raise UnPairException
    return index_min[0], int(random.random() * (args.top_k_num - 1)) + 1


def get_corresponding_relation(src_points, tgt_points, R, t):
    src_points = src_points.detach().numpy()
    tgt_points = tgt_points.detach().numpy()
    R = R.detach().numpy()
    t = t.detach().numpy()
    src_points = torch.tensor(np.matmul(R, src_points)).permute(1, 0) + t
    tgt_points = torch.tensor(tgt_points).permute(1, 0)
    positive_data = []
    negative_data = []
    for i in range(src_points.__len__()):
        try:
            positive_data_single, negative_data_single = get_distance_sorted_idx(src_points[i], tgt_points)
        except UnPairException:
            positive_data.append("UNPAIR")
            negative_data.append("UNPAIR")
        else:
            positive_data.append(positive_data_single)
            negative_data.append(negative_data_single)
    return positive_data, negative_data


def get_aver(data_list):
    add = float(0)
    for data in data_list:
        add += data
    if len(data_list) == 0:
        return 0
    return add / len(data_list)


def random_Rotation():
    angle = int(random.random() * (args.min_angle - args.max_angle) + args.max_angle)
    angle = np.pi / angle
    angle_x = np.random.uniform() * angle
    angle_y = np.random.uniform() * angle
    angle_z = np.random.uniform() * angle

    cos_x = np.cos(angle_x)
    cos_y = np.cos(angle_y)
    cos_z = np.cos(angle_z)
    sin_x = np.sin(angle_x)
    sin_y = np.sin(angle_y)
    sin_z = np.sin(angle_z)
    Rx = np.array([[1, 0, 0],
                   [0, cos_x, -sin_x],
                   [0, sin_x, cos_x]])
    Ry = np.array([[cos_y, 0, sin_y],
                   [0, 1, 0],
                   [-sin_y, 0, cos_y]])
    Rz = np.array([[cos_z, -sin_z, 0],
                   [sin_z, cos_z, 0],
                   [0, 0, 1]])
    R = Rx.dot(Ry).dot(Rz)
    t = np.random.uniform(-0.5, 0.5, size=3)
    euler = np.array([angle_z, angle_y, angle_x])

    return R, t, euler


def ensure_path(path):
    if not isdir(os.path.dirname(path)):
        os.mkdir(os.path.dirname(path))


def ensure_delete(path):
    if isfile(path):
        os.remove(path)


def random_down_sample(pointcloud, goal_num):
    list0 = []
    while len(list0) != goal_num:
        unit = random.randint(0, pointcloud.__len__())
        if unit not in list0:
            list0.append(unit)
    return pointcloud[list0]


def Write_out_txt(dimension, data, goal_path, typ):
    if os.path.isfile(goal_path):
        os.remove(goal_path)
    io = IOStream(goal_path)
    if dimension == 1:
        if typ != "numpy":
            np_data = data.numpy()
        else:
            np_data = data
        for i in range(np_data.__len__()):
            io.println(str(np_data[i]).replace('[', '').replace(']', ''))
    elif dimension == 2:
        if typ != "numpy":
            np_data = data.numpy()
        else:
            np_data = data
        for i in range(np_data.__len__()):
            for ii in range(np_data[i].__len__()):
                io.print(str(np_data[i][ii]).replace('[', '').replace(']', ''))
            io.ln()


def o3d_knn_maker(pointcloud, ran):
    pointcloud = np.array(pointcloud)
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(pointcloud)
    pc_tree = o3d.geometry.KDTreeFlann(pcd)
    kdtree = []
    for i in tqdm(range(pcd.points.__len__())):
        tmp_data = pc_tree.search_knn_vector_3d(pcd.points[i], ran + 1)[1]
        for ii in range(tmp_data.__len__()):
            kdtree.append(tmp_data[ii])
    return kdtree


def get_k_idx(score, k):
    score, score_idx = torch.sort(score, dim=-1, descending=True)
    top_k_idx = score_idx[:, 0:k]
    return top_k_idx


def according_to_ab_from_ABC_choose_abC(data, idx):
    # data shape: numpy_B,N,K,3 or tensor_B,N,128
    # idx shape: B,TOP_K
    # return shape: B,TOP_K,K,3 or B,TOP_K,128
    tmp_data_block = []
    for i in range(data.shape[0]):
        tmp_data_block.append(data[i, idx[i]])
    if str(type(data)) == "<class 'torch.Tensor'>":
        tmp_data_block = torch.stack(tmp_data_block)
    else:
        tmp_data_block = np.asarray(tmp_data_block)
    return tmp_data_block


def feature_fusion(nk256, nk128):
    nk256 = nk256.permute(0, 2, 1)
    nk384 = torch.cat((nk128, nk256), 2)
    return nk384


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


class IOStream:
    def __init__(self, path):
        self.f = open(path, 'a')

    def cprint(self, text):
        self.f.write(text + '\n')
        self.f.flush()

    def close(self):
        self.f.close()

    def print(self, text):
        self.f.write(text + " ")
        self.f.flush()

    def ln(self):
        self.f.write('\n')
        self.f.flush()

    def println(self, text):
        self.f.write(text + '\n')
        self.f.flush()


def jitter_pointcloud(pointcloud, sigma=0.01, clip=0.05):
    N, C = pointcloud.shape
    pointcloud = pointcloud + np.clip(sigma * np.random.randn(N, C), -1 * clip, clip)
    return pointcloud


def visualization(points1, points2):
    skip = 1
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    point_range = range(0, points1.shape[0], skip)
    x = points1[point_range, 0]
    y = points1[point_range, 1]
    z = points1[point_range, 2]
    ax.scatter(x, y, z, c='g', cmap='Blues', marker="o")
    ax.axis('auto')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('feature visualization')

    point_range = range(0, points2.shape[0], skip)
    x = points2[point_range, 0]
    y = points2[point_range, 1]
    z = points2[point_range, 2]
    ax.scatter(x, y, z, c='r', cmap='Blues', marker="o")
    ax.axis('auto')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('feature visualization')

    ax.axis('off')
    ax.grid(False)
    plt.show()


class UnPairException(Exception):
    def __init__(self):
        pass
