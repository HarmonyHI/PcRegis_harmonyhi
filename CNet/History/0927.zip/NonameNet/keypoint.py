import torch
import torch.nn as nn
import torch.nn.functional as nn_func
import args
from args import knn_num, top_k_num
from utils import according_to_ab_from_ABC_choose_abC, get_k_idx


class KeypointDetector(nn.Module):
    def __init__(self, out, Knn_num):
        super(KeypointDetector, self).__init__()
        self.conv1 = nn.Conv2d(10, out[0], kernel_size=1)
        self.bn1 = nn.BatchNorm2d(out[0], eps=1e-6, momentum=0.01)
        self.conv2 = nn.Conv2d(out[0], out[1], kernel_size=1)
        self.bn2 = nn.BatchNorm2d(out[1], eps=1e-6, momentum=0.01)
        self.conv3 = nn.Conv2d(out[1], out[2], kernel_size=1)
        self.bn3 = nn.BatchNorm2d(out[2], eps=1e-6, momentum=0.01)
        self.pool3 = AttentivePooling(out[2], out[2])
        self.mlp = MLP()
        self.knn_num = Knn_num

    def forward(self, pointcloud, pc_knn):
        xyz = self.relative_pos_encoding(pointcloud, pc_knn)
        xyz = nn_func.leaky_relu(self.bn1(self.conv1(xyz)), negative_slope=0.2)
        xyz = nn_func.leaky_relu(self.bn2(self.conv2(xyz)), negative_slope=0.2)
        xyz = nn_func.leaky_relu(self.bn3(self.conv3(xyz)), negative_slope=0.2)
        xyz = self.pool3(xyz).squeeze(-1)
        N128 = xyz
        N128 = N128.permute(0, 2, 1)
        score = self.mlp(xyz)
        score = score.permute(0, 2, 1)
        score = score.squeeze(-1)
        return score, N128

    def relative_pos_encoding(self, xyz, neighbor_xyz):
        neighbor_xyz = neighbor_xyz.permute(0, 3, 1, 2).contiguous()
        xyz = xyz[:, :, None, :].permute(0, 3, 1, 2).contiguous()
        repeated_xyz = xyz.repeat(1, 1, 1, self.knn_num)
        relative_xyz = repeated_xyz - neighbor_xyz
        relative_dist = torch.sqrt(torch.sum(relative_xyz ** 2, dim=1, keepdim=True))
        relative_feature = torch.cat([relative_dist, relative_xyz, repeated_xyz, neighbor_xyz], dim=1)
        return relative_feature


class AttentivePooling(nn.Module):
    def __init__(self, n_feature, d_out):
        super().__init__()
        self.n_feature = n_feature
        self.fc1 = nn.Linear(n_feature, n_feature, bias=False)
        self.conv1 = nn.Conv2d(n_feature, d_out, kernel_size=1)
        self.bn1 = nn.BatchNorm2d(d_out, eps=1e-6, momentum=0.01)

    def forward(self, x):
        batch_size = x.shape[0]
        num_points = x.shape[2]
        num_neigh = x.shape[3]
        x = x.permute(0, 2, 3, 1).contiguous()
        x = torch.reshape(x, [-1, num_neigh, self.n_feature])
        att_activation = self.fc1(x)
        att_score = nn_func.softmax(att_activation, dim=1)
        x = x * att_score
        x = torch.sum(x, dim=1)
        x = torch.reshape(x, [batch_size, num_points, self.n_feature])[:, :, :, None].permute(0, 2, 1,
                                                                                              3).contiguous()
        x = nn_func.leaky_relu(self.bn1(self.conv1(x)), negative_slope=0.2)
        return x


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(128, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.fc3(x)
        x = self.relu(x)
        x = x.permute(0, 2, 1)
        return x


def get_super_points(pc, pc_kdtree):
    pc = torch.tensor(pc)
    pc_kdtree = torch.tensor(pc_kdtree)
    Keypoint = KeypointDetector([32, 64, 128], knn_num).to(args.device)
    with torch.no_grad():
        idx, N128 = Keypoint(pc, pc_kdtree)
    Sp_index = get_k_idx(idx, top_k_num).detach().numpy()
    NK128 = according_to_ab_from_ABC_choose_abC(N128, Sp_index)
    return Sp_index, NK128
