from os.path import isfile
import torch
import args
from torch import optim
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from tqdm import tqdm
from FeatureNet import FeatureNet
from data import ModelNet40
from util import seed_everything, ensure_path, ensure_delete


def train_one_epoch(model, loader, opt, epoch):
    loss_sum = 0
    counter = 0
    for R, t, euler, src_knn, tgt_knn, nk128 in tqdm(loader):
        src_knn = src_knn.cpu()
        tgt_knn = tgt_knn.cpu()
        opt.zero_grad()
        src_feature, tgt_feature, loss = model(src_knn, tgt_knn, nk128, R, t)
        loss.backward(retain_graph=True)
        loss_sum += loss
        counter = counter + 1
        opt.step()
    print(f"========== Epoch {epoch + 1} rank {loss_sum / counter}==============")


def train(network, loader):
    network.train()
    opt = optim.Adam(network.parameters(), lr=0.0001, weight_decay=0.001)
    scheduler = MultiStepLR(opt, milestones=[40, 85], gamma=0.1)
    for epoch in range(args.epochs):
        train_one_epoch(network, loader, opt, epoch)
        scheduler.step()


def test(network, loader):
    for epoch in range(args.epochs):
        batch = 0
        for R, t, euler, src_knn, tgt_knn, nk128 in tqdm(loader):
            batch = batch + 1
            src_knn = src_knn.cpu()
            tgt_knn = tgt_knn.cpu()
            src_feature, tgt_feature, loss = network(src_knn, tgt_knn, nk128, R, t)
            print(f"***************** epoch {epoch} batch {batch} **********************")
            print(src_feature)
            print(tgt_feature)
            print(src_feature - tgt_feature)
            print(f"**************************************************")


if __name__ == '__main__':
    seed_everything(args.random_seed)
    train_loader = DataLoader(
        ModelNet40(partition=args.partition, gaussian_noise=args.gaussian_noise),
        batch_size=args.batch_size, shuffle=args.shuffle, drop_last=args.drop_last, num_workers=args.num_workers)
    ensure_path(args.net_path)
    if isfile(args.net_path) and not args.is_train:
        print("load net from file")
        m_state_dict = torch.load(args.net_path)
        net = FeatureNet().to(args.device)
        net.load_state_dict(m_state_dict)
        test(net, train_loader)
    else:
        net = FeatureNet().to(args.device)
        train(net, train_loader)
        ensure_delete(args.net_path)
        torch.save(net.state_dict(), args.net_path)
        print("save net successfully")
