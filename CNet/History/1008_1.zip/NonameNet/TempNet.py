import sys

import torch
import torch.nn as nn
import args
from utils import get_corresponding_relation, feature_fusion, get_k_idx, \
    according_to_ab_from_ABC_choose_abC, Write_out_txt, UnPairException, sort_points_as_features, get_R_t, get_muse
import torch.nn.functional as nn_func


class Conv1DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, ksize):
        super(Conv1DBNReLU, self).__init__()
        self.conv = nn.Conv1d(in_channel, out_channel, ksize, bias=False)
        self.bn = nn.BatchNorm1d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv2DBNReLU(nn.Module):
    def __init__(self, in_channel, out_channel, ksize):
        super(Conv2DBNReLU, self).__init__()
        self.conv = nn.Conv2d(in_channel, out_channel, ksize, bias=False)
        self.bn = nn.BatchNorm2d(out_channel)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Conv1DBlock(nn.Module):
    def __init__(self, channels, ksize):
        super(Conv1DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv1DBNReLU(channels[i], channels[i + 1], ksize))
        self.conv.append(nn.Conv1d(channels[-2], channels[-1], ksize))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Conv2DBlock(nn.Module):
    def __init__(self, channels, ksize):
        super(Conv2DBlock, self).__init__()
        self.conv = nn.ModuleList()
        for i in range(len(channels) - 2):
            self.conv.append(Conv2DBNReLU(channels[i], channels[i + 1], ksize))
        self.conv.append(nn.Conv2d(channels[-2], channels[-1], ksize))

    def forward(self, x):
        for conv in self.conv:
            x = conv(x)
        return x


class Propagate(nn.Module):
    def __init__(self, in_channel, emb_dims):
        super(Propagate, self).__init__()
        self.conv2d = Conv2DBlock((in_channel, emb_dims, emb_dims), 1)
        self.conv1d = Conv1DBlock((emb_dims, emb_dims), 1)

    def forward(self, x, knn_p):
        x_f = knn_p - x.unsqueeze(-1)
        x_f = x_f.type(args.tensor_format)
        x_f = self.conv2d(x_f)
        x = x_f.max(-1)[0]
        x = self.conv1d(x)
        return x, x_f


class GNN(nn.Module):
    def __init__(self):
        super(GNN, self).__init__()
        self.propagate1 = Propagate(3, 32)
        self.propagate2 = Propagate(32, 64)
        self.propagate3 = Propagate(64, 128)
        self.propagate4 = Propagate(128, 256)

    def forward(self, x_knn):
        x = x_knn[:, :, :, 0:1].squeeze()
        x, x_f = self.propagate1(x, x_knn)
        x, x_f = self.propagate2(x, x_f)
        x, x_f = self.propagate3(x, x_f)
        x, x_f = self.propagate4(x, x_f)
        return x


class SpatialAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = Conv2DBlock((2, 1), 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=2, keepdim=True)
        max_out, _ = torch.max(x, dim=2, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=2)
        x = x.permute((2, 1, 0))
        x = self.conv(x)
        return self.sigmoid(x).permute(2, 1, 0).squeeze(-1)


class CircleLoss(nn.Module):
    def __init__(self, m, gamma):
        super(CircleLoss, self).__init__()
        self.m = m
        self.gamma = gamma
        self.soft_plus = nn.Softplus()

    def forward(self, sp, sn):
        ap = torch.clamp_min(- sp.detach() + 1 + self.m, min=0.)
        an = torch.clamp_min(sn.detach() + self.m, min=0.)
        delta_p = 1 - self.m
        delta_n = self.m
        logit_p = - ap * (sp - delta_p) * self.gamma
        logit_n = an * (sn - delta_n) * self.gamma
        loss = self.soft_plus(torch.logsumexp(logit_n, dim=0) + torch.logsumexp(logit_p, dim=0))
        return loss


class KeypointDetector(nn.Module):
    def __init__(self, out):
        super(KeypointDetector, self).__init__()
        self.knn_num = args.knn_num
        self.conv1 = nn.Conv2d(10, out[0], kernel_size=1)
        self.bn1 = nn.BatchNorm2d(out[0], eps=1e-6, momentum=0.01)
        self.conv2 = nn.Conv2d(out[0], out[1], kernel_size=1)
        self.bn2 = nn.BatchNorm2d(out[1], eps=1e-6, momentum=0.01)
        self.conv3 = nn.Conv2d(out[1], out[2], kernel_size=1)
        self.bn3 = nn.BatchNorm2d(out[2], eps=1e-6, momentum=0.01)
        self.pool3 = AttentivePooling(out[2], out[2])
        self.mlp = MLP()

    def forward(self, pointcloud, pc_knn):
        xyz = self.relative_pos_encoding(pointcloud, pc_knn)
        xyz = nn_func.leaky_relu(self.bn1(self.conv1(xyz.to(torch.float32))), negative_slope=0.2)
        xyz = nn_func.leaky_relu(self.bn2(self.conv2(xyz)), negative_slope=0.2)
        xyz = nn_func.leaky_relu(self.bn3(self.conv3(xyz)), negative_slope=0.2)
        xyz = self.pool3(xyz).squeeze(-1)
        N128 = xyz
        N128 = N128.permute(0, 2, 1)
        score = self.mlp(xyz)
        score = score.permute(0, 2, 1)
        score = score.squeeze(-1)
        loss = 0
        return score, N128, loss

    def relative_pos_encoding(self, xyz, neighbor_xyz):
        neighbor_xyz = neighbor_xyz.permute(0, 3, 1, 2).contiguous()
        xyz = xyz[:, :, None, :].permute(0, 3, 1, 2).contiguous()
        repeated_xyz = xyz.repeat(1, 1, 1, self.knn_num)
        relative_xyz = repeated_xyz - neighbor_xyz
        relative_dist = torch.sqrt(torch.sum(relative_xyz ** 2, dim=1, keepdim=True))
        relative_feature = torch.cat([relative_dist, relative_xyz, repeated_xyz, neighbor_xyz], dim=1) \
            .to(args.tensor_format)
        return relative_feature


class AttentivePooling(nn.Module):
    def __init__(self, n_feature, d_out):
        super().__init__()
        self.n_feature = n_feature
        self.fc1 = nn.Linear(n_feature, n_feature, bias=False)
        self.conv1 = nn.Conv2d(n_feature, d_out, kernel_size=1)
        self.bn1 = nn.BatchNorm2d(d_out, eps=1e-6, momentum=0.01)

    def forward(self, x):
        batch_size = x.shape[0]
        num_points = x.shape[2]
        num_neigh = x.shape[3]
        x = x.permute(0, 2, 3, 1).contiguous()
        x = torch.reshape(x, [-1, num_neigh, self.n_feature])
        att_activation = self.fc1(x)
        att_score = nn_func.softmax(att_activation, dim=1)
        x = x * att_score
        x = torch.sum(x, dim=1)
        x = torch.reshape(x, [batch_size, num_points, self.n_feature])[:, :, :, None].permute(0, 2, 1,
                                                                                              3).contiguous()
        x = nn_func.leaky_relu(self.bn1(self.conv1(x)), negative_slope=0.2)
        return x


class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(128, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.fc3(x)
        x = self.relu(x)
        x = x.permute(0, 2, 1)
        return x


class SVDHead(nn.Module):
    def __init__(self):
        super(SVDHead, self).__init__()
        self.reflect = nn.Parameter(torch.eye(3), requires_grad=False)
        self.reflect[2, 2] = -1

    def forward(self, src, src_corr, weights):
        src_centered = src - src.mean(dim=2, keepdim=True)
        src_corr_centered = src_corr - src_corr.mean(dim=2, keepdim=True)
        H = torch.matmul(src_centered * weights.unsqueeze(1), src_corr_centered.transpose(2, 1).contiguous())
        R = []
        for i in range(src.size(0)):
            u, s, v = torch.svd(H[i])
            r = torch.matmul(v, u.transpose(1, 0).contiguous())
            r_det = torch.det(r)
            if r_det < 0:
                u, s, v = torch.svd(H[i])
                v = torch.matmul(v, self.reflect)
                r = torch.matmul(v, u.transpose(1, 0).contiguous())
            R.append(r)
        R = torch.stack(R, dim=0)
        t = torch.matmul(-R, (weights.unsqueeze(1) * src).sum(dim=2, keepdim=True)) + (
                weights.unsqueeze(1) * src_corr).sum(dim=2, keepdim=True)
        return R, t.view(src.size(0), 3)


class TempNet(nn.Module):
    def __init__(self):
        super(TempNet, self).__init__()
        self.fc1 = nn.Linear(384, 512, bias=False)
        self.fc2 = nn.Linear(512, 256, bias=False)
        self.fc3 = nn.Linear(256, 128, bias=False)
        self.emb_nn = GNN()
        self.circle_loss = CircleLoss(m=0.25, gamma=256)
        self.spatial_attention = SpatialAttention()
        self.keypoint_detector = KeypointDetector([32, 64, 128])

    def forward(self, src_knn, tgt_knn, R=None, t=None):
        with torch.no_grad():
            src_knn = src_knn.to(args.device)
            src_knn = src_knn.permute((0, 1, 3, 2))
            pc_sampled_A = src_knn[:, :, 0, :]
            knn_sampled_A = src_knn[:, :, 1::, :]
            tgt_knn = tgt_knn.to(args.device)
            tgt_knn = tgt_knn.permute((0, 1, 3, 2))
            pc_sampled_B = tgt_knn[:, :, 0, :]
            knn_sampled_B = tgt_knn[:, :, 1::, :]
            Sp_index_A, nk128_A, super_points_loss_A = self.get_super_points(pc_sampled_A, knn_sampled_A)
            Sp_index_B, nk128_B, super_points_loss_B = self.get_super_points(pc_sampled_B, knn_sampled_B)
            src_knn = according_to_ab_from_ABC_choose_abC(src_knn, Sp_index_A)
            tgt_knn = according_to_ab_from_ABC_choose_abC(tgt_knn, Sp_index_B)
            if args.raise_sampled_knn_super:
                Write_out_txt(2, src_knn, args.tmp_sampled_knn_super_path_A, "tensor")
                Write_out_txt(2, tgt_knn, args.tmp_sampled_knn_super_path_B, "tensor")
            src_knn = src_knn.permute((0, 3, 1, 2))
            tgt_knn = tgt_knn.permute((0, 3, 1, 2))
        src_embedding = self.emb_nn(src_knn)
        tgt_embedding = self.emb_nn(tgt_knn)
        src_fusion_feature = feature_fusion(src_embedding, nk128_A)
        tgt_fusion_feature = feature_fusion(tgt_embedding, nk128_B)
        src_feature = self.fc1(src_fusion_feature)
        src_feature = self.fc2(src_feature)
        src_feature = self.fc3(src_feature)
        tgt_feature = self.fc1(tgt_fusion_feature)
        tgt_feature = self.fc2(tgt_feature)
        tgt_feature = self.fc3(tgt_feature)
        src_total_real_points = src_knn[:, :, :, 0]
        tgt_total_real_points = tgt_knn[:, :, :, 0]
        tgt_points_sorted = sort_points_as_features(tgt_total_real_points, src_feature, tgt_feature)
        rotation_predict, translation_predict = get_R_t(src_total_real_points, tgt_points_sorted)
        rotation_muse = get_muse(rotation_predict, R)
        translation_muse = get_muse(translation_predict, t)
        if args.is_train:
            attention_matrix_A = self.spatial_attention(src_feature)
            attention_matrix_B = self.spatial_attention(tgt_feature)
            loss_arr = []
            for batch_iter in range(args.batch_size):
                loss_arr_batch = []
                src_batch_point = src_total_real_points[batch_iter, :, :]
                tgt_batch_point = tgt_total_real_points[batch_iter, :, :]
                positive_data, negative_data, positive_distance = get_corresponding_relation(src_batch_point,
                                                                                             tgt_batch_point,
                                                                                             R[batch_iter],
                                                                                             t[batch_iter])
                # sys.exit(0)
                for point_item in range(args.top_k_num):
                    if isinstance(positive_data[point_item], UnPairException) or \
                            isinstance(negative_data[point_item], UnPairException):
                        if args.print_debug_info:
                            print(f"{positive_data[point_item].toString()}")
                        continue
                    print(f"============debug===========")
                    print(nn_func.pairwise_distance(src_feature[batch_iter][point_item],tgt_feature[batch_iter][positive_data[point_item]]))
                    print(nn_func.pairwise_distance(src_feature[batch_iter][point_item],tgt_feature[batch_iter][negative_data[point_item]]))
                    print(positive_distance[point_item])
                    print(f"==============end=================")
                    sp = nn_func.pairwise_distance(tgt_feature[batch_iter][positive_data[point_item]]
                                                   * attention_matrix_B[batch_iter][positive_data[point_item]],
                                                   src_feature[batch_iter][point_item]
                                                   * attention_matrix_A[batch_iter][point_item])
                    sn = nn_func.pairwise_distance(tgt_feature[batch_iter][negative_data[point_item]]
                                                   * attention_matrix_B[batch_iter][negative_data[point_item]],
                                                   src_feature[batch_iter][point_item]
                                                   * attention_matrix_A[batch_iter][point_item])
                    loss_arr_batch.append(self.circle_loss(sp, sn))
                loss_arr.append(torch.stack(loss_arr_batch).sum() / loss_arr_batch.__len__())
            loss = torch.stack(loss_arr).sum() / loss_arr.__len__() + super_points_loss_A + super_points_loss_B
            return R, rotation_predict, rotation_muse, t, translation_predict, translation_muse, loss
        else:
            return R, rotation_predict, rotation_muse, t, translation_predict, translation_muse

    def get_super_points(self, pc, pc_kdtree):
        score, n128, loss = self.keypoint_detector(pc, pc_kdtree)
        sp_index = get_k_idx(score, args.top_k_num).detach().numpy()
        nk128 = according_to_ab_from_ABC_choose_abC(n128, sp_index)
        return sp_index, nk128, loss
