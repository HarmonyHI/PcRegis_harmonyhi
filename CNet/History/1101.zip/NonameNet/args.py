import torch
from utils import to_md5

do_train = True
do_test = False
disable_keypoint = True
gaussian_noise = False
unseen = False
shuffle = True
drop_last = True
last_loss = None
feat_match_info = None
now_epoch = None
debug_output_corr_based_feat_epoch = 1
split_block = 2048
split_number = 72
sample_num = split_block * split_number
batch_size = 4
epochs = 200
xyz_dis_limit = 0.8
feat_dis_limit = 20
knn_num = 64
knn_dis = 0.8
knn_max_empty_num = 5
top_k_num = 2048
num_workers = 2
learn_rate = 0.001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
device = torch.device("cpu" if torch.cuda.is_available() else "cpu")
numpy_format = 'float32'
tensor_format = torch.float32
reduction = 'mean'

junk_dir = "F:\\code_junk\\"
src_path = "F:\\WHU\\WHU_dir\\6-Campus\\9.txt"
tgt_path = "F:\\WHU\\WHU_dir\\6-Campus\\10.txt"
rt_path = "F:\\WHU\\WHU_dir\\6-Campus\\9-10\\transformation.txt"
src_cache_name = to_md5(src_path[-9::] + str(knn_num) + str(knn_dis) + str(knn_max_empty_num) + str(xyz_dis_limit))
tgt_cache_name = to_md5(tgt_path[-9::] + str(knn_num) + str(knn_dis) + str(knn_max_empty_num) + str(xyz_dis_limit))
net_path = junk_dir + "saved_net.torchnet"
src_knn_path = junk_dir + f"knn_{src_cache_name}.npy"
tgt_knn_path = junk_dir + f"knn_{tgt_cache_name}.npy"
src_corr_idx_path = junk_dir + f"corr_{src_cache_name}.npy"
tgt_corr_idx_path = junk_dir + f"corr_{tgt_cache_name}.npy"
