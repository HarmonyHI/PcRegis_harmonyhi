import os
import torch


is_train = False
raise_sampled_knn = False
raise_sampled_knn_super = False
gaussian_noise = False
shuffle = True
drop_last = True
max_match_limit = 1
margin = 0.4
p = 2
down_sample_num = 8192
knn_num = 64
top_k_num = 500
tile_number = 3
batch_size = 1
epochs = 50
max_angle = 5
min_angle = 2
random_seed = 50
positive_num = 1
negative_num = 4
num_workers = 2
lr = 0.0001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLOUD_DIR = os.path.dirname(os.path.dirname(BASE_DIR)) + "/PointCloudDir/"
pc_file_name = "campus_down_sample"
pc_path = CLOUD_DIR + pc_file_name + ".txt"
tmp_sampled_knn_super_path = CLOUD_DIR + "tmp_sampled_knn_super.txt"
tmp_sampled_knn_path = CLOUD_DIR + "tmp_sampled_knn.txt"
raw_knn_path = CLOUD_DIR + f"knn_{knn_num}_{pc_file_name}.npy"
net_path = BASE_DIR + "/saved_net/0920.pkl"
data_format = 'float32'
reduction = 'mean'
partition = 'train'
