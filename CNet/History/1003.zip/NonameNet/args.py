import os
import torch


is_train = True
raise_sampled_knn = False
raise_sampled_knn_super = False
gaussian_noise = False
shuffle = True
drop_last = True
print_debug_info = False
max_match_limit = 5
margin = 0.4
p = 2
down_sample_num = 8192
knn_num = 64
top_k_num = 500
split_number = 8
batch_size = 4
epochs = 100
min_angle = 10
max_angle = 7
max_trans = 0.05
random_seed = 50
num_workers = 2
learn_rate = 0.001
weight_decay = 0.001
milestones = [40, 85]
gamma = 0.1
negative_point_distance = 2
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLOUD_DIR = BASE_DIR + "\\PointCloudDir\\"
net_path = BASE_DIR + "\\saved_net\\NonameNet.pkl"
pc_file_name = "campus_down_sample"
pc_path = CLOUD_DIR + pc_file_name + ".txt"
tmp_sampled_knn_super_path_A = CLOUD_DIR + "tmp_sampled_knn_super_A.txt"
tmp_sampled_knn_super_path_B = CLOUD_DIR + "tmp_sampled_knn_super_B.txt"
tmp_sampled_knn_path = CLOUD_DIR + "tmp_sampled_knn.txt"
raw_knn_path = CLOUD_DIR + f"knn_{knn_num}_{pc_file_name}.npy"

numpy_format = 'float32'
tensor_format = torch.float32
reduction = 'mean'
