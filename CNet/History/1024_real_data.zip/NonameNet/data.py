import os.path
import sys
import numpy as np
from torch.utils.data import Dataset
import args
import utils
from utils import neighbour_maker, ensure_path


def load_point_cloud(path, knn_path, knn_num, raw_sample_num, data_format, split_block):
    try:
        pc = np.loadtxt(path, dtype=data_format)  # [n, 3]
    except OSError:
        ensure_path(path)
        print(f"{path} is not found, please check")
        sys.exit(1)
    if os.path.isfile(knn_path):
        pc_knn_idx = np.load(knn_path, allow_pickle=True)
        if not pc_knn_idx.__len__() == (pc.shape[0] * (knn_num + 1)):
            print("knn is broken, rebuilding")
            pc_knn_idx = np.asarray(neighbour_maker(pc, knn_num))
            np.save(knn_path, pc_knn_idx)
        else:
            print("knn loaded from file")
    else:
        print("not found knn, creating")
        pc_knn_idx = np.asarray(neighbour_maker(pc, knn_num))
        np.save(knn_path, pc_knn_idx)
        print("knn saved")
    pc_knn_idx = pc_knn_idx.reshape(pc.shape[0], knn_num + 1)  # [n, knn_num + 1]
    pc_knn = pc[pc_knn_idx]  # [n, knn_num + 1, 3]
    pc_knn = utils.random_down_sample(pc_knn, raw_sample_num)
    pc_knn = np.stack(np.array_split(pc_knn, pc_knn.shape[0] // split_block))  # [b, point_num , knn_num + 1 , 3]
    return pc_knn


def load_rt_matrix(path, data_format):
    try:
        matrix = np.loadtxt(path, dtype=data_format)  # [n, 3]
    except OSError:
        ensure_path(path)
        print(f"{path} is not found, please check")
        sys.exit(1)
    rotate_matrix = matrix[0:3, 0:3]
    trans_matrix = matrix[0:3, 3]
    return rotate_matrix, trans_matrix


class WhuDataset(Dataset):
    def __init__(self, partition, gaussian_noise, unseen):
        super(WhuDataset, self).__init__()
        self.partition = partition
        self.gaussian_noise = gaussian_noise
        self.unseen = unseen
        self.src_knn = load_point_cloud(args.src_path, args.src_knn_path, args.knn_num,
                                        args.raw_sample_num, args.numpy_format, args.split_block)
        self.tgt_knn = load_point_cloud(args.tgt_path, args.tgt_knn_path, args.knn_num,
                                        args.raw_sample_num, args.numpy_format, args.split_block)
        self.rot_matrix, self.trans_matrix = load_rt_matrix(args.rt_path, args.numpy_format)

    def __getitem__(self, item):
        point_cloud1_knn = np.random.permutation(self.src_knn[item].transpose(0, 2, 1))
        point_cloud2_knn = np.random.permutation(self.tgt_knn[item].transpose(0, 2, 1))
        rot = self.rot_matrix
        trans = self.trans_matrix
        return point_cloud1_knn, point_cloud2_knn, rot, trans

    def __len__(self):
        if self.src_knn.shape[0] < self.tgt_knn.shape[0]:
            return self.src_knn.shape[0]
        return self.tgt_knn.shape[0]
