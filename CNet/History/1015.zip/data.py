import os.path
import sys
import numpy as np
from torch.utils.data import Dataset
import args
import utils
from args import pc_path, knn_num, down_sample_num, numpy_format, tmp_sampled_knn_path, \
    raw_knn_path, raise_sampled_knn
from utils import o3d_knn_maker, random_rotation, \
    write_out_txt, ensure_path


def load_from_file():
    try:
        pc = np.loadtxt(pc_path, dtype=numpy_format)  # [n, 3]
    except OSError:
        ensure_path(pc_path)
        print(f"{pc_path} is not found, please check")
        sys.exit(1)
    if os.path.isfile(raw_knn_path):
        pc_knn_idx = np.load(raw_knn_path, allow_pickle=True)
        if not pc_knn_idx.__len__() == (pc.shape[0] * (knn_num + 1)):
            print("knn is broken, rebuilding")
            pc_knn_idx = np.asarray(o3d_knn_maker(pc, knn_num))
            np.save(raw_knn_path, pc_knn_idx)
        else:
            print("knn loaded from file")
    else:
        print("not found knn, creating")
        pc_knn_idx = np.asarray(o3d_knn_maker(pc, knn_num))
        np.save(raw_knn_path, pc_knn_idx)
        print("knn saved")
    pc_knn_idx = pc_knn_idx.reshape(pc.shape[0], knn_num + 1)  # [n, knn_num + 1]
    pc_knn = pc[pc_knn_idx]  # [n, knn_num + 1, 3]
    pc_knn = utils.random_down_sample(pc_knn, down_sample_num)
    pc_knn = batch_divider(pc_knn)  # [b, point_num , knn_num + 1 , 3]
    if raise_sampled_knn:
        write_out_txt(2, pc_knn, tmp_sampled_knn_path, "numpy")
    return pc_knn


def batch_divider(data):
    if data.shape[0] % args.split_block != 0:
        print(f"sample num {data.shape[0]} can not to be divisible by split block {args.split_block}")
        sys.exit(1)
    if args.batch_size > (data.shape[0] // args.split_block):
        print(f"batch size {args.batch_size} can not be bigger than split number {data.shape[0] // args.split_block}")
        sys.exit(1)
    data = np.stack(np.array_split(data, data.shape[0] // args.split_block))
    return data


class ModelNet40(Dataset):
    def __init__(self, partition, gaussian_noise=False, unseen=False):
        super(ModelNet40, self).__init__()
        self.partition = partition
        self.gaussian_noise = gaussian_noise
        self.unseen = unseen
        self.data_knn = load_from_file()

    def __getitem__(self, item):
        point_cloud1_knn = self.data_knn[item].transpose(0, 2, 1)
        R_ab, translation_ab, euler_ab = random_rotation()
        point_cloud2_knn = np.matmul(R_ab, point_cloud1_knn) + translation_ab[:, np.newaxis]
        point_cloud1_knn = np.random.permutation(point_cloud1_knn)
        point_cloud2_knn = np.random.permutation(point_cloud2_knn)
        return R_ab.astype(numpy_format), translation_ab.astype(numpy_format), \
            euler_ab.astype(numpy_format), point_cloud1_knn, point_cloud2_knn

    def __len__(self):
        return self.data_knn.shape[0]
