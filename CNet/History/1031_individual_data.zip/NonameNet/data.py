import os.path
import sys
import numpy as np
import torch
from torch.utils.data import Dataset
import args
import utils
from utils import neighbour_maker, ensure_path


def load_rt_matrix(path, data_format):
    try:
        matrix = np.loadtxt(path, dtype=data_format)  # [n, 3]
    except OSError:
        ensure_path(path)
        print(f"{path} is not found, please check")
        sys.exit(1)
    rotate_matrix = matrix[0:3, 0:3]
    trans_matrix = matrix[0:3, 3]
    return rotate_matrix, trans_matrix


def load_point_cloud(path, knn_path, knn_num, data_format):
    try:
        pc = np.loadtxt(path, dtype=data_format)  # [n, 3]
    except OSError:
        ensure_path(path)
        print(f"{path} is not found, please check")
        sys.exit(1)
    if os.path.isfile(knn_path):
        pc_knn_idx = np.load(knn_path, allow_pickle=True)
        if not pc_knn_idx.__len__() == (pc.shape[0] * (knn_num + 1)):
            print("knn is broken, rebuilding")
            pc_knn_idx = np.asarray(neighbour_maker(pc, knn_num))
            np.save(knn_path, pc_knn_idx)
        else:
            print("knn loaded from file")
    else:
        print("not found knn, creating")
        pc_knn_idx = np.asarray(neighbour_maker(pc, knn_num))
        np.save(knn_path, pc_knn_idx)
        print("knn saved")
    pc_knn_idx = pc_knn_idx.reshape(pc.shape[0], knn_num + 1)  # [n, knn_num + 1]
    pc_knn = pc[pc_knn_idx]  # [n, knn_num + 1, 3]
    return pc_knn


def get_corr_node(src_knn, tgt_knn, rot, trans):
    """
    Input:
        src_knn: numpy [n-src, k-nearest-neighbour, 3]
        tgt_knn: numpy [n-tgt, k-nearest-neighbour, 3]
        rot: [3, 3]
        trans: [3, 1]
    Return:
        src_knn_corr, tgt_knn_corr: tensor [n-paired, k-nearest-neighbour, 3]
    """
    src_knn = torch.tensor(src_knn).unsqueeze(0)
    tgt_knn = torch.tensor(tgt_knn).unsqueeze(0)
    rot = torch.tensor(rot)
    trans = torch.tensor(trans)
    if os.path.isfile(args.src_corr_idx_path) and os.path.isfile(args.tgt_corr_idx_path):
        src_knn_corr_idx = np.load(args.src_corr_idx_path, allow_pickle=True)
        tgt_knn_corr_idx = np.load(args.tgt_corr_idx_path, allow_pickle=True)
        print("corr loaded from file")
    else:
        print("finding corr node")
        src_xyz = src_knn[:, :, 0, :]
        tgt_xyz = tgt_knn[:, :, 0, :]
        src_knn_corr_idx, tgt_knn_corr_idx, _ = utils.find_match_pair(src_xyz, tgt_xyz, rot, trans)
        np.save(args.src_corr_idx_path, src_knn_corr_idx)
        np.save(args.tgt_corr_idx_path, tgt_knn_corr_idx)
        print("corr node saved")
    src_knn_corr = utils.tensor_rebuild(src_knn, src_knn_corr_idx).squeeze()
    tgt_knn_corr = utils.tensor_rebuild(tgt_knn, tgt_knn_corr_idx).squeeze()
    corr_node = torch.stack([src_knn_corr, tgt_knn_corr]).permute((1, 0, 2, 3))
    return corr_node


class WhuDataset(Dataset):
    def __init__(self, partition, gaussian_noise, unseen):
        super(WhuDataset, self).__init__()
        self.partition = partition
        self.gaussian_noise = gaussian_noise
        self.unseen = unseen
        self.src_knn = load_point_cloud(args.src_path, args.src_knn_path, args.knn_num, args.numpy_format)
        self.tgt_knn = load_point_cloud(args.tgt_path, args.tgt_knn_path, args.knn_num, args.numpy_format)
        if args.do_train:
            self.rot_matrix, self.trans_matrix = load_rt_matrix(args.rt_path, args.numpy_format)
            corr_node = get_corr_node(self.src_knn, self.tgt_knn, self.rot_matrix, self.trans_matrix)
            corr_node = utils.random_down_sample(corr_node, args.sample_num)
            corr_node = corr_node.reshape((args.split_number, args.split_block,
                                           corr_node.shape[1], corr_node.shape[2], corr_node.shape[3]))
            self.src_knn = corr_node[:, :, 0, :, :]
            self.tgt_knn = corr_node[:, :, 1, :, :]
        else:
            self.src_knn = utils.random_down_sample(self.src_knn, args.sample_num)
            self.src_knn = np.stack(np.array_split(self.src_knn, args.split_number))
            self.tgt_knn = utils.random_down_sample(self.tgt_knn, args.sample_num)
            self.tgt_knn = np.stack(np.array_split(self.tgt_knn, args.split_number))

    def __getitem__(self, item):
        return self.src_knn[item], self.tgt_knn[item]

    def __len__(self):
        if self.src_knn.shape[0] < self.tgt_knn.shape[0]:
            return self.src_knn.shape[0]
        return self.tgt_knn.shape[0]
